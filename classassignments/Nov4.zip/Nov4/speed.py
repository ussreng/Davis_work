distance = float(input("Enter distance: "))
time = float(input("Enter time: "))

speed = distance / time
print("Speed =", speed)