l = float(input("Enter length: "))
b = float(input("Enter breadth: "))

area = l * b
perimeter = 2 * (l + b)

print("Area =", area)
print("Perimeter =", perimeter)
